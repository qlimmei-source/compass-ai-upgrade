#!/bin/bash
# Mac twin of tidy.ps1: tidies the mess folder by the rules file next to this script. Moves only, deletes and replaces nothing.
# Run: bash tidy.sh
here="$(cd "$(dirname "$0")" && pwd)"; dz="$(dirname "$here")"
rules="$(ls "$here"/*.txt | head -1)"
body="$(grep -v '^[[:space:]]*#' "$rules" | grep -v '^[[:space:]]*$')"
keys="$(printf '%s\n' "$body" | grep -v '|' | sed 's/^[^:]*:[[:space:]]*//')"
mess_name="$(printf '%s\n' "$keys" | sed -n 1p)"; backup_name="$(printf '%s\n' "$keys" | sed -n 2p)"; list_name="$(printf '%s\n' "$keys" | sed -n 3p)"
rl="$(printf '%s\n' "$body" | grep '|')"
mess="$dz/$mess_name"; list="$mess/$list_name"
if [ -e "$list" ]; then echo "ALREADY: tidy, see $list"; exit 0; fi
boxes="$(printf '%s\n' "$rl" | awk -F'|' '{gsub(/^[ \t]+|[ \t]+$/,"",$1); print $1}')"
archive_box="$(printf '%s\n' "$boxes" | sed -n 1p)"
bk="$dz/$backup_name/$mess_name $(date '+%Y-%m-%d %H-%M')"
mkdir -p "$bk"
tmp="$(mktemp)"
for it in "$mess"/*; do
  n="$(basename "$it")"; printf '%s\n' "$boxes" | grep -qxF "$n" && continue
  cp -R "$it" "$bk/"; printf '%s\n' "$it" >> "$tmp"
done
echo "BACKUP: $bk"
printf '%s\n' "$boxes" | while IFS= read -r b; do mkdir -p "$mess/$b"; done
placed="$(mktemp)"; count=0
while IFS= read -r it; do
  n="$(basename "$it")"; low="$(printf '%s' "$n" | tr '[:upper:]' '[:lower:]' | perl -CS -pe '$_=lc')"
  box=""
  if [ -d "$it" ]; then box="$archive_box"; else
    while IFS= read -r line; do
      b="$(printf '%s' "$line" | awk -F'|' '{gsub(/^[ \t]+|[ \t]+$/,"",$1); print $1}')"
      words="$(printf '%s' "$line" | awk -F'|' '{for(i=3;i<=NF;i++){w=$i; gsub(/^[ \t]+|[ \t]+$/,"",w); print w}}' | perl -CS -pe '$_=lc')"
      while IFS= read -r w; do
        if [ "$w" = "*" ] || case "$low" in *"$w"*) true;; *) false;; esac; then box="$b"; break; fi
      done <<< "$words"
      [ -n "$box" ] && break
    done <<< "$rl"
  fi
  mv -n "$it" "$mess/$box/"; printf '%s\t%s\n' "$box" "$n" >> "$placed"; count=$((count+1))
  echo "MOVED: $n -> $box"; sleep 0.3
done < "$tmp"
{
  printf '%s\n\n' "${list_name%.*}"
  printf '%s\n' "$rl" | sort | while IFS= read -r line; do
    b="$(printf '%s' "$line" | awk -F'|' '{gsub(/^[ \t]+|[ \t]+$/,"",$1); print $1}')"
    why="$(printf '%s' "$line" | awk -F'|' '{gsub(/^[ \t]+|[ \t]+$/,"",$2); print $2}' | perl -CS -pe 's/^(.)/\u$1/')"
    printf '%s — %s.\n' "$b" "$why"
    files="$(awk -F'\t' -v b="$b" '$1==b{print $2}' "$placed" | sort)"
    if [ -z "$files" ]; then printf '   · —\n'; else printf '%s\n' "$files" | sed 's/^/   · /'; fi
    printf '\n'
  done
} > "$list"
echo "LIST: $list"
echo "DONE: moved $count, boxes $(printf '%s\n' "$boxes" | wc -l | tr -d ' '), deleted 0"
