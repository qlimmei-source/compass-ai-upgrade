# Builds a styled .xlsx (opens in Excel and Google Sheets) from a JSON description. No Python, no Excel needed.
# Run: powershell -NoProfile -ExecutionPolicy Bypass -File make_xlsx.ps1 -Spec "<path to .json, UTF-8>" [-Base64]
# -Base64 also prints the file as one base64 line (for uploading to Google Drive as a Google Sheet).
# JSON: { "file": "<full path to .xlsx>", "sheets": [ { "name": "...", "title": "...",
#         "columns": [ { "name": "...", "width": 20, "align": "left|center", "format": "0.0" } ],
#         "rows": [ [ ... ], ... ], "status": { "<cell text>": "good|warn|bad" } } ] }
# Optional: "colors": [ [style or null per column] per row ] with styles good|good2|warn|bad|spec|name|g1|g2|g3 (cell fill, kept in Google Sheets); "legend": [[style, text], ...] under the table.
# Header row - Pistachio, rows - zebra, header frozen, filter on header, status cells coloured. Creates a new file, replaces nothing.
param([Parameter(Mandatory = $true)][string]$Spec, [switch]$Base64)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$s = Get-Content -LiteralPath $Spec -Raw -Encoding UTF8 | ConvertFrom-Json
$out = $s.file
[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($out)))
if (Test-Path -LiteralPath $out) {
    $out = [IO.Path]::Combine([IO.Path]::GetDirectoryName($out), [IO.Path]::GetFileNameWithoutExtension($out) + ' ' + (Get-Date -Format 'yyyy-MM-dd HH-mm-ss') + '.xlsx')
}
function Esc([string]$t) { [Security.SecurityElement]::Escape($t) }
function Col([int]$i) { $n = ''; $i++; while ($i -gt 0) { $m = ($i - 1) % 26; $n = [char](65 + $m) + $n; $i = [int][math]::Floor(($i - 1) / 26) }; $n }
function IsNum($v) { ($v -is [int]) -or ($v -is [long]) -or ($v -is [double]) -or ($v -is [decimal]) }

$styles = @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="1"><numFmt numFmtId="164" formatCode="0.0"/></numFmts>
<fonts count="4">
<font><sz val="11"/><name val="Arial"/></font>
<font><b/><sz val="11"/><name val="Arial"/></font>
<font><b/><sz val="16"/><name val="Arial"/></font>
<font><b/><sz val="11"/><color rgb="FFCB3B39"/><name val="Arial"/></font>
</fonts>
<fills count="14">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFACB948"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE5E4DF"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF5F4EF"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFBFD97A"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE3EEC2"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF7DC8B"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF4B8B6"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFD9C9EA"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEEF0DC"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFCFE3F3"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFCBE8E2"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFD6DDF2"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFD9D9D9"/></left><right style="thin"><color rgb="FFD9D9D9"/></right><top style="thin"><color rgb="FFD9D9D9"/></top><bottom style="thin"><color rgb="FFD9D9D9"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="30">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="164" fontId="0" fillId="4" borderId="1" xfId="0" applyNumberFormat="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="3" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="7" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="7" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="3" fillId="8" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="3" fillId="8" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="9" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="9" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="1" fillId="10" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="1" fillId="10" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="11" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="11" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="12" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="12" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="13" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="13" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>
'@

$sheetXml = @(); $names = @(); $defined = @()
$si = 0
foreach ($sh in $s.sheets) {
    $cols = @($sh.columns); $nc = $cols.Count; $last = Col ($nc - 1)
    $rows = @($sh.rows); $lastRow = $rows.Count + 2
    $cm = @{ good = 0; good2 = 1; warn = 2; bad = 3; spec = 4; name = 5; g1 = 6; g2 = 7; g3 = 8 }
    $colRows = @(); if ($sh.colors) { $colRows = @($sh.colors) }
    $st = @{}; if ($sh.status) { $sh.status.PSObject.Properties | ForEach-Object { $st[$_.Name] = $_.Value } }
    $b = New-Object Text.StringBuilder
    [void]$b.Append('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">')
    [void]$b.Append('<sheetViews><sheetView workbookViewId="0"' + $(if ($si -eq 0) { ' tabSelected="1"' } else { '' }) + '><pane ySplit="2" topLeftCell="A3" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A3" sqref="A3"/></sheetView></sheetViews>')
    [void]$b.Append('<sheetFormatPr defaultRowHeight="20" customHeight="1"/><cols>')
    for ($i = 0; $i -lt $nc; $i++) { $w = if ($cols[$i].width) { $cols[$i].width } else { 16 }; [void]$b.Append("<col min=`"$($i+1)`" max=`"$($i+1)`" width=`"$w`" customWidth=`"1`"/>") }
    [void]$b.Append('</cols><sheetData>')
    [void]$b.Append('<row r="1" ht="32" customHeight="1"><c r="A1" s="1" t="inlineStr"><is><t>' + (Esc $sh.title) + '</t></is></c></row>')
    [void]$b.Append('<row r="2" ht="26" customHeight="1">')
    for ($i = 0; $i -lt $nc; $i++) { [void]$b.Append("<c r=`"$(Col $i)2`" s=`"2`" t=`"inlineStr`"><is><t>" + (Esc $cols[$i].name) + '</t></is></c>') }
    [void]$b.Append('</row>')
    $r = 3
    foreach ($row in $rows) {
        $z = ($r % 2 -eq 0)
        [void]$b.Append("<row r=`"$r`" ht=`"22`" customHeight=`"1`">")
        $vals = @($row)
        for ($i = 0; $i -lt $nc; $i++) {
            $v = if ($i -lt $vals.Count) { $vals[$i] } else { $null }
            $ref = "$(Col $i)$r"
            $ck = $null; if ($colRows.Count -gt ($r - 3)) { $cr = @($colRows[$r - 3]); if ($i -lt $cr.Count -and $cr[$i]) { $ck = [string]$cr[$i] } }
            if ($ck -and $cm.ContainsKey($ck)) { $x = 12 + 2 * $cm[$ck] + $(if ($cols[$i].align -eq 'center' -or (IsNum $v)) { 0 } else { 1 }) }
            elseif ($null -ne $v -and $st.ContainsKey([string]$v)) { $x = @{ good = 9; warn = 10; bad = 11 }[[string]$st[[string]$v]] }
            elseif ($cols[$i].format) { $x = if ($z) { 8 } else { 7 } }
            elseif ($cols[$i].align -eq 'center' -or (IsNum $v)) { $x = if ($z) { 6 } else { 5 } }
            else { $x = if ($z) { 4 } else { 3 } }
            if ($null -eq $v -or [string]$v -eq '') { [void]$b.Append("<c r=`"$ref`" s=`"$x`"/>") }
            elseif (IsNum $v) { [void]$b.Append("<c r=`"$ref`" s=`"$x`"><v>" + ([double]$v).ToString([Globalization.CultureInfo]::InvariantCulture) + '</v></c>') }
            else { [void]$b.Append("<c r=`"$ref`" s=`"$x`" t=`"inlineStr`"><is><t>" + (Esc ([string]$v)) + '</t></is></c>') }
        }
        [void]$b.Append('</row>'); $r++
    }
    $lr = $lastRow + 2
    if ($sh.legend) { foreach ($lg in @($sh.legend)) { $lg = @($lg); [void]$b.Append("<row r=`"$lr`" ht=`"22`" customHeight=`"1`"><c r=`"B$lr`" s=`"$(12 + 2 * $cm[[string]$lg[0]] + 1)`" t=`"inlineStr`"><is><t>" + (Esc ([string]$lg[1])) + '</t></is></c></row>'); $lr++ } }
    [void]$b.Append("</sheetData><autoFilter ref=`"A2:$last$lastRow`"/><mergeCells count=`"1`"><mergeCell ref=`"A1:${last}1`"/></mergeCells>")
    [void]$b.Append('<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/><pageSetup orientation="landscape"/></worksheet>')
    $sheetXml += $b.ToString(); $names += [string]$sh.name
    $defined += "<definedName name=`"_xlnm._FilterDatabase`" localSheetId=`"$si`" hidden=`"1`">'" + (Esc ([string]$sh.name -replace "'", "''")) + "'!`$A`$2:`$$last`$$lastRow</definedName>"
    $si++
}

$n = $sheetXml.Count
$ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
for ($i = 1; $i -le $n; $i++) { $ct += "<Override PartName=`"/xl/worksheets/sheet$i.xml`" ContentType=`"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml`"/>" }
$ct += '</Types>'
$rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
$wb = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>'
$wr = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
for ($i = 1; $i -le $n; $i++) {
    $wb += "<sheet name=`"" + (Esc $names[$i - 1]) + "`" sheetId=`"$i`" r:id=`"rId$i`"/>"
    $wr += "<Relationship Id=`"rId$i`" Type=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet`" Target=`"worksheets/sheet$i.xml`"/>"
}
$wb += '</sheets><definedNames>' + ($defined -join '') + '</definedNames></workbook>'
$wr += "<Relationship Id=`"rId$($n+1)`" Type=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles`" Target=`"styles.xml`"/></Relationships>"

$parts = [ordered]@{ '[Content_Types].xml' = $ct; '_rels/.rels' = $rels; 'xl/workbook.xml' = $wb; 'xl/_rels/workbook.xml.rels' = $wr; 'xl/styles.xml' = $styles }
for ($i = 1; $i -le $n; $i++) { $parts["xl/worksheets/sheet$i.xml"] = $sheetXml[$i - 1] }
$enc = New-Object Text.UTF8Encoding($false)
$fs = [IO.File]::Open($out, [IO.FileMode]::CreateNew)
$zip = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create)
foreach ($k in $parts.Keys) {
    $e = $zip.CreateEntry($k, [IO.Compression.CompressionLevel]::Optimal)
    $w = New-Object IO.StreamWriter($e.Open(), $enc); $w.Write($parts[$k]); $w.Dispose()
}
$zip.Dispose(); $fs.Dispose()
Write-Output ("XLSX: " + $out)
if ($Base64) { Write-Output ("BASE64: " + [Convert]::ToBase64String([IO.File]::ReadAllBytes($out))) }
