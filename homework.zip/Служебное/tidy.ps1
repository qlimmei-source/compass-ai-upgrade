# Tidies the mess folder of the homework by the rules in the rules file next to this script (UTF-8 text, Russian).
# Run: powershell -NoProfile -ExecutionPolicy Bypass -File tidy.ps1
# 1) full copy of the mess folder into the backup folder (time in the name); 2) box folders; 3) moves every file
# into the first box whose word is in its name (subfolders go to the last-but-one rule box "09 ..."); 4) writes the list file.
# Moves only. Deletes and replaces nothing. Run again after tidying - prints ALREADY and does nothing.
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$dz = Split-Path -Parent $here
$rulesFile = Get-ChildItem -LiteralPath $here -Filter '*.txt' | Select-Object -First 1
$lines = Get-Content -LiteralPath $rulesFile.FullName -Encoding UTF8 | Where-Object { $_.Trim() -ne '' -and -not $_.TrimStart().StartsWith('#') }
$keys = @($lines | Where-Object { $_ -notmatch '\|' } | ForEach-Object { ($_ -split ':', 2)[1].Trim() })
$messName = $keys[0]; $backupName = $keys[1]; $listName = $keys[2]
$rules = @($lines | Where-Object { $_ -match '\|' } | ForEach-Object {
    $p = $_ -split '\|' | ForEach-Object { $_.Trim() }
    [pscustomobject]@{ Box = $p[0]; Why = $p[1]; Words = @($p[2..($p.Count - 1)] | ForEach-Object { $_.ToLower() }) }
})
$mess = Join-Path $dz $messName
$list = Join-Path $mess $listName
if (Test-Path -LiteralPath $list) { Write-Output ("ALREADY: tidy, see " + $list); exit 0 }
$boxNames = @($rules | ForEach-Object { $_.Box })
$items = @(Get-ChildItem -LiteralPath $mess | Where-Object { $boxNames -notcontains $_.Name })
# 1. backup
$bk = Join-Path (Join-Path $dz $backupName) ($messName + ' ' + (Get-Date -Format 'yyyy-MM-dd HH-mm'))
New-Item -ItemType Directory -Force -Path $bk | Out-Null
$items | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $bk -Recurse }
Write-Output ("BACKUP: " + $bk)
# 2. boxes
foreach ($r in $rules) { New-Item -ItemType Directory -Force -Path (Join-Path $mess $r.Box) | Out-Null }
# 3. move
$archiveBox = $rules[0].Box
$placed = @{}
foreach ($r in $rules) { $placed[$r.Box] = New-Object System.Collections.ArrayList }
foreach ($it in $items) {
    $name = $it.Name.ToLower()
    $box = $null
    if ($it.PSIsContainer) { $box = $archiveBox }
    else {
        foreach ($r in $rules) {
            foreach ($w in $r.Words) { if ($w -eq '*' -or $name.Contains($w)) { $box = $r.Box; break } }
            if ($box) { break }
        }
    }
    Move-Item -LiteralPath $it.FullName -Destination (Join-Path $mess $box)
    [void]$placed[$box].Add($it.Name)
    Write-Output ("MOVED: " + $it.Name + " -> " + $box)
    Start-Sleep -Milliseconds 300
}
# 4. list file
$dash = [char]0x2014; $dot = [char]0x00B7
$out = New-Object System.Collections.ArrayList
[void]$out.Add([IO.Path]::GetFileNameWithoutExtension($listName)); [void]$out.Add('')
foreach ($r in ($rules | Sort-Object Box)) {
    $why = $r.Why.Substring(0, 1).ToUpper() + $r.Why.Substring(1)
    [void]$out.Add($r.Box + ' ' + $dash + ' ' + $why + '.')
    if ($placed[$r.Box].Count -eq 0) { [void]$out.Add('   ' + $dot + ' ' + $dash) }
    foreach ($f in ($placed[$r.Box] | Sort-Object)) { [void]$out.Add('   ' + $dot + ' ' + $f) }
    [void]$out.Add('')
}
Set-Content -LiteralPath $list -Value $out -Encoding UTF8
Write-Output ("LIST: " + $list)
Write-Output ("DONE: moved " + $items.Count + ", boxes " + $rules.Count + ", deleted 0")
