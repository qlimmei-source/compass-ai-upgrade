#!/bin/bash
# Mac twin of submit.ps1 (version 2): ONE zip "<Surname Name> — домашнее задание.zip" in the folder "Сдать" inside the homework folder.
# Nothing on the Desktop or in Downloads, no screenshots. Only whitelisted result files + "О работе.txt" (3 lines). Deletes and replaces nothing.
# Run: bash submit.sh "<Surname Name>" "<department>" "<what was done>" "<how long>"
# Test: SUBMIT_NO_OPEN=1
here="$(cd "$(dirname "$0")" && pwd)"; dz="$(dirname "$here")"
who="$1"; dept="$2"; did="$3"; tm="$4"
out="$dz/Сдать"; mkdir -p "$out" || exit 1
safe="$(printf '%s' "${who:-работа}" | tr '/\:*?"<>|' '         ')"
zip="$out/$safe — домашнее задание.zip"; [ -e "$zip" ] && zip="$out/$safe — домашнее задание $(date '+%Y-%m-%d %H-%M-%S').zip"
rules="$(ls "$here"/*.txt | head -1)"
mess_name="$(grep -v '^[[:space:]]*#' "$rules" | grep -v '^[[:space:]]*$' | grep -v '|' | sed -n 1p | sed 's/^[^:]*:[[:space:]]*//')"
cd "$dz" || exit 1
dirs=("$mess_name"); for d in *\ 2\ * *\ 3; do [ -d "$d" ] && dirs+=("$d"); done
tmp="$(mktemp -d)"
printf 'Департамент: %s\nЧто сделано: %s\nСколько ушло времени: %s\n' "$dept" "$did" "$tm" > "$tmp/О работе.txt"
/usr/bin/zip -qr "$zip" "${dirs[@]}" -i '*.html' '*.css' '*.js' '*.md' '*.txt' '*.csv' '*.xlsx' '*.docx' '*.png' '*.jpg' '*.jpeg' '*.svg' '*.pdf' '*.json' -x '*/.*' \
  && (cd "$tmp" && /usr/bin/zip -q "$zip" "О работе.txt") && echo "ZIP: $zip"
echo "FOLDER: $out"
[ -z "$SUBMIT_NO_OPEN" ] && open "$out"
