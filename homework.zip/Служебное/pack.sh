#!/bin/bash
# Mac twin of pack.ps1: packs the mess folder, task 2 and task 3 folders into one .zip. Deletes and replaces nothing.
# Run: bash pack.sh "<Surname Name>"
here="$(cd "$(dirname "$0")" && pwd)"; dz="$(dirname "$here")"; who="$*"
rules="$(ls "$here"/*.txt | head -1)"
mess_name="$(grep -v '^[[:space:]]*#' "$rules" | grep -v '^[[:space:]]*$' | grep -v '|' | sed -n 1p | sed 's/^[^:]*:[[:space:]]*//')"
cd "$dz" || exit 1
set -- "$mess_name"; for d in *\ 2\ *  *\ 3; do [ -d "$d" ] && set -- "$@" "$d"; done
for d in "$@"; do echo "IN: $d"; done
base="$(basename "$dz") — $who"; zip="$dz/$base.zip"
[ -e "$zip" ] && zip="$dz/$base $(date '+%Y-%m-%d %H-%M').zip"
/usr/bin/zip -qr "$zip" "$@" && echo "ZIP: $zip"
