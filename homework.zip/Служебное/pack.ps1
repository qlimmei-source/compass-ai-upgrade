# Packs the homework results into one .zip next to the homework folder content: mess folder (tidied), task 2 and task 3 folders.
# Run: powershell -NoProfile -ExecutionPolicy Bypass -File pack.ps1 "<Surname Name>"
# Creates a new archive; if one with this name exists, the new one gets the time in its name. Deletes and replaces nothing.
$ErrorActionPreference = 'Stop'
$who = ($args -join ' ').Trim()
$here = $PSScriptRoot; $dz = Split-Path -Parent $here
$rulesFile = Get-ChildItem -LiteralPath $here -Filter '*.txt' | Select-Object -First 1
$messName = ((Get-Content -LiteralPath $rulesFile.FullName -Encoding UTF8 | Where-Object { $_.Trim() -ne '' -and -not $_.TrimStart().StartsWith('#') -and $_ -notmatch '\|' } | Select-Object -First 1) -split ':', 2)[1].Trim()
$dirs = @(Get-ChildItem -LiteralPath $dz -Directory | Where-Object { $_.Name -eq $messName -or $_.Name -match '^\S+ [23]( |$)' } | ForEach-Object { $_.FullName })
foreach ($d in $dirs) { Write-Output ("IN: " + (Split-Path -Leaf $d)) }
$base = (Split-Path -Leaf $dz) + ' ' + [char]0x2014 + ' ' + $who
$zip = Join-Path $dz ($base + '.zip')
if (Test-Path -LiteralPath $zip) { $zip = Join-Path $dz ($base + ' ' + (Get-Date -Format 'yyyy-MM-dd HH-mm') + '.zip') }
# Files open in Excel or a browser are read too (shared read), so the person does not need to close them.
Add-Type -AssemblyName System.IO.Compression
$fs = [IO.File]::Open($zip, [IO.FileMode]::CreateNew)
$za = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create)
$count = 0
foreach ($d in $dirs) {
    $root = Split-Path -Parent $d
    Get-ChildItem -LiteralPath $d -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring($root.Length + 1).Replace([string][char]92, '/')
        $e = $za.CreateEntry($rel, [IO.Compression.CompressionLevel]::Optimal)
        $src = [IO.File]::Open($_.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
        $dst = $e.Open(); $src.CopyTo($dst); $dst.Dispose(); $src.Dispose(); $count++
    }
}
$za.Dispose(); $fs.Dispose()
Write-Output ("FILES: " + $count)
Write-Output ("ZIP: " + $zip)
