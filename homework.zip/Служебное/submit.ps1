﻿# Submit helper, version 2. Builds ONE zip "<Surname Name> — домашнее задание.zip" in the folder "Сдать" INSIDE the homework folder.
# Nothing on the Desktop, nothing in Downloads, no screenshots. Only whitelisted result files from the task folders go into the zip,
# plus "О работе.txt" (3 lines). Deletes and replaces nothing: a repeat submit makes a new zip with date-time in its name.
# Run: powershell -NoProfile -ExecutionPolicy Bypass -File submit.ps1 -Name "<Surname Name>" -Dept "<department>" -Did "<what was done>" -Time "<how long>"
# Test switch (not for people): -NoOpen.
param([string]$Name = '', [string]$Dept = '', [string]$Did = '', [string]$Time = '', [switch]$NoOpen)
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot; $dz = Split-Path -Parent $here
$out = Join-Path $dz 'Сдать'
if (-not (Test-Path -LiteralPath $out)) { New-Item -ItemType Directory -Path $out | Out-Null }

# task folders: mess folder (name from the rules file), "... 2 ...", "... 3 ..."
$rulesFile = Get-ChildItem -LiteralPath $here -Filter '*.txt' | Select-Object -First 1
$messName = ((Get-Content -LiteralPath $rulesFile.FullName -Encoding UTF8 | Where-Object { $_.Trim() -ne '' -and -not $_.TrimStart().StartsWith('#') -and $_ -notmatch '\|' } | Select-Object -First 1) -split ':', 2)[1].Trim()
$dirs = @(Get-ChildItem -LiteralPath $dz -Directory | Where-Object { $_.Name -eq $messName -or $_.Name -match '^\S+ [23]( |$)' } | ForEach-Object { $_.FullName })

$white = @('.html', '.css', '.js', '.md', '.txt', '.csv', '.xlsx', '.docx', '.png', '.jpg', '.jpeg', '.svg', '.pdf', '.json')
$safe = ($(if ($Name) { $Name } else { 'работа' }) -replace '[\/:*?"<>|]', ' ').Trim()
$zipName = $safe + ' ' + [char]0x2014 + ' домашнее задание.zip'
$zip = Join-Path $out $zipName
if (Test-Path -LiteralPath $zip) { $zip = Join-Path $out ($safe + ' ' + [char]0x2014 + ' домашнее задание ' + (Get-Date -Format 'yyyy-MM-dd HH-mm-ss') + '.zip') }

Add-Type -AssemblyName System.IO.Compression
$fs = [IO.File]::Open($zip, [IO.FileMode]::CreateNew)
$za = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create)
$count = 0; $skipped = 0
foreach ($d in $dirs) {
    $root = Split-Path -Parent $d
    Get-ChildItem -LiteralPath $d -Recurse -File | ForEach-Object {
        if ($white -notcontains $_.Extension.ToLowerInvariant()) { $skipped++; return }
        $rel = $_.FullName.Substring($root.Length + 1).Replace([string][char]92, '/')
        $e = $za.CreateEntry($rel, [IO.Compression.CompressionLevel]::Optimal)
        $src = [IO.File]::Open($_.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
        $dst = $e.Open(); $src.CopyTo($dst); $dst.Dispose(); $src.Dispose(); $count++
    }
}
# "О работе.txt" straight into the zip: three lines
$lines = @(('Департамент: ' + $Dept), ('Что сделано: ' + $Did), ('Сколько ушло времени: ' + $Time))
$e = $za.CreateEntry('О работе.txt', [IO.Compression.CompressionLevel]::Optimal)
$w = New-Object IO.StreamWriter($e.Open(), (New-Object Text.UTF8Encoding($false)))
$w.Write(($lines -join "`r`n") + "`r`n"); $w.Dispose()
$za.Dispose(); $fs.Dispose()
Write-Output ("FILES: " + $count)
Write-Output ("SKIPPED: " + $skipped)
Write-Output ("ZIP: " + $zip)
Write-Output ("FOLDER: " + $out)
if (-not $NoOpen) { Start-Process -FilePath $out }
