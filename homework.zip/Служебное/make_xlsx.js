// Builds a styled .xlsx (opens in Excel, Numbers and Google Sheets) from a JSON description. Mac version of make_xlsx.ps1.
// Run on Mac: osascript -l JavaScript make_xlsx.js "<path to .json, UTF-8>" [--base64]   (built into macOS; uses the built-in zip command)
// --base64 also prints the file as one base64 line (for uploading to Google Drive as a Google Sheet).
// JSON format - see make_xlsx.ps1. Creates a new file, replaces nothing.
function esc(t) { return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;'); }
function col(i) { var n = ''; i++; while (i > 0) { var m = (i - 1) % 26; n = String.fromCharCode(65 + m) + n; i = Math.floor((i - 1) / 26); } return n; }
var STYLES = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
  '<numFmts count="1"><numFmt numFmtId="164" formatCode="0.0"/></numFmts><fonts count="4">' +
  '<font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="11"/><name val="Arial"/></font>' +
  '<font><b/><sz val="16"/><name val="Arial"/></font><font><b/><sz val="11"/><color rgb="FFCB3B39"/><name val="Arial"/></font></fonts>' +
  '<fills count="14"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>' +
  '<fill><patternFill patternType="solid"><fgColor rgb="FFACB948"/><bgColor indexed="64"/></patternFill></fill>' +
  '<fill><patternFill patternType="solid"><fgColor rgb="FFE5E4DF"/><bgColor indexed="64"/></patternFill></fill>' +
  '<fill><patternFill patternType="solid"><fgColor rgb="FFF5F4EF"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFBFD97A"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE3EEC2"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF7DC8B"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF4B8B6"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFD9C9EA"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEEF0DC"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFCFE3F3"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFCBE8E2"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFD6DDF2"/><bgColor indexed="64"/></patternFill></fill></fills>' +
  '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFD9D9D9"/></left><right style="thin"><color rgb="FFD9D9D9"/></right><top style="thin"><color rgb="FFD9D9D9"/></top><bottom style="thin"><color rgb="FFD9D9D9"/></bottom><diagonal/></border></borders>' +
  '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="30">' +
  '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +
  '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment vertical="center"/></xf>' +
  '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>' +
  '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf>' +
  '<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf>' +
  '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' +
  '<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' +
  '<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' +
  '<xf numFmtId="164" fontId="0" fillId="4" borderId="1" xfId="0" applyNumberFormat="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' +
  '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' +
  '<xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' +
  '<xf numFmtId="0" fontId="3" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' +
  '<xf numFmtId="0" fontId="0" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="7" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="7" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="3" fillId="8" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="3" fillId="8" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="9" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="9" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="1" fillId="10" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="1" fillId="10" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="11" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="11" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="12" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="12" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf><xf numFmtId="0" fontId="0" fillId="13" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="13" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" indent="1"/></xf>' +
  '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';

var CM = { good: 0, good2: 1, warn: 2, bad: 3, spec: 4, name: 5, g1: 6, g2: 7, g3: 8 };  // optional "colors" per row and "legend": see make_xlsx.ps1
function parts(spec) {
  var sheets = [], names = [], defined = [];
  spec.sheets.forEach(function (sh, si) {
    var cols = sh.columns, nc = cols.length, last = col(nc - 1), rows = sh.rows || [], lastRow = rows.length + 2, st = sh.status || {};
    var b = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';
    b += '<sheetViews><sheetView workbookViewId="0"' + (si === 0 ? ' tabSelected="1"' : '') + '><pane ySplit="2" topLeftCell="A3" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A3" sqref="A3"/></sheetView></sheetViews>';
    b += '<sheetFormatPr defaultRowHeight="20" customHeight="1"/><cols>';
    cols.forEach(function (c, i) { b += '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + (c.width || 16) + '" customWidth="1"/>'; });
    b += '</cols><sheetData><row r="1" ht="32" customHeight="1"><c r="A1" s="1" t="inlineStr"><is><t>' + esc(sh.title || '') + '</t></is></c></row><row r="2" ht="26" customHeight="1">';
    cols.forEach(function (c, i) { b += '<c r="' + col(i) + '2" s="2" t="inlineStr"><is><t>' + esc(c.name) + '</t></is></c>'; });
    b += '</row>';
    rows.forEach(function (row, k) {
      var r = k + 3, z = (r % 2 === 0);
      b += '<row r="' + r + '" ht="22" customHeight="1">';
      for (var i = 0; i < nc; i++) {
        var v = i < row.length ? row[i] : null, ref = col(i) + r, x, num = (typeof v === 'number');
        var ck = (sh.colors && sh.colors[k]) ? sh.colors[k][i] : null;
        if (ck && CM.hasOwnProperty(ck)) x = 12 + 2 * CM[ck] + ((cols[i].align === 'center' || num) ? 0 : 1);
        else if (v !== null && v !== undefined && Object.prototype.hasOwnProperty.call(st, String(v))) x = { good: 9, warn: 10, bad: 11 }[st[String(v)]];
        else if (cols[i].format) x = z ? 8 : 7;
        else if (cols[i].align === 'center' || num) x = z ? 6 : 5;
        else x = z ? 4 : 3;
        if (v === null || v === undefined || v === '') b += '<c r="' + ref + '" s="' + x + '"/>';
        else if (num) b += '<c r="' + ref + '" s="' + x + '"><v>' + v + '</v></c>';
        else b += '<c r="' + ref + '" s="' + x + '" t="inlineStr"><is><t>' + esc(v) + '</t></is></c>';
      }
      b += '</row>';
    });
    var lr = lastRow + 2;
    (sh.legend || []).forEach(function (lg) { b += '<row r="' + lr + '" ht="22" customHeight="1"><c r="B' + lr + '" s="' + (12 + 2 * CM[lg[0]] + 1) + '" t="inlineStr"><is><t>' + esc(lg[1]) + '</t></is></c></row>'; lr++; });
    b += '</sheetData><autoFilter ref="A2:' + last + lastRow + '"/><mergeCells count="1"><mergeCell ref="A1:' + last + '1"/></mergeCells>';
    b += '<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/><pageSetup orientation="landscape"/></worksheet>';
    sheets.push(b); names.push(String(sh.name));
    defined.push('<definedName name="_xlnm._FilterDatabase" localSheetId="' + si + '" hidden="1">\'' + esc(String(sh.name).replace(/'/g, "''")) + '\'!$A$2:$' + last + '$' + lastRow + '</definedName>');
  });
  var n = sheets.length, ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
  var wb = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>';
  var wr = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
  for (var i = 1; i <= n; i++) {
    ct += '<Override PartName="/xl/worksheets/sheet' + i + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
    wb += '<sheet name="' + esc(names[i - 1]) + '" sheetId="' + i + '" r:id="rId' + i + '"/>';
    wr += '<Relationship Id="rId' + i + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + i + '.xml"/>';
  }
  ct += '</Types>';
  wb += '</sheets><definedNames>' + defined.join('') + '</definedNames></workbook>';
  wr += '<Relationship Id="rId' + (n + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
  var p = { '[Content_Types].xml': ct, '_rels/.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
    'xl/workbook.xml': wb, 'xl/_rels/workbook.xml.rels': wr, 'xl/styles.xml': STYLES };
  for (var j = 1; j <= n; j++) p['xl/worksheets/sheet' + j + '.xml'] = sheets[j - 1];
  return p;
}

if (typeof ObjC !== 'undefined') {
  ObjC.import('Foundation');
  var run = function (argv) {
    var app = Application.currentApplication(); app.includeStandardAdditions = true;
    var q = function (s) { return "'" + String(s).replace(/'/g, "'\\''") + "'"; };
    var spec = JSON.parse($.NSString.stringWithContentsOfFileEncodingError(argv[0], $.NSUTF8StringEncoding, null).js);
    var out = spec.file, fm = $.NSFileManager.defaultManager;
    app.doShellScript('mkdir -p ' + q(out.substring(0, out.lastIndexOf('/'))));
    if (fm.fileExistsAtPath(out)) out = out.replace(/\.xlsx$/i, '') + ' ' + app.doShellScript('date "+%Y-%m-%d %H-%M-%S"') + '.xlsx';
    var tmp = app.doShellScript('mktemp -d'), p = parts(spec);
    Object.keys(p).forEach(function (k) {
      var f = tmp + '/' + k, d = f.substring(0, f.lastIndexOf('/'));
      fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError(d, true, $(), null);
      $(p[k]).writeToFileAtomicallyEncodingError(f, true, $.NSUTF8StringEncoding, null);
    });
    app.doShellScript('cd ' + q(tmp) + ' && zip -X -r -q ' + q(out) + ' ' + q('[Content_Types].xml') + ' _rels xl');
    var res = 'XLSX: ' + out;
    if (argv[1] === '--base64') res += '\nBASE64: ' + app.doShellScript('base64 -i ' + q(out) + " | tr -d '\\n'");
    return res;
  };
} else if (typeof module !== 'undefined') {
  module.exports = { parts: parts };  // for testing on a computer with Node
}
