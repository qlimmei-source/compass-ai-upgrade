# Opens files, folders or https links for the person (default program: browser, Excel, Explorer). Changes nothing.
# Run: powershell -NoProfile -ExecutionPolicy Bypass -File open.ps1 "<path or link>" ["<path or link>" ...]
$ErrorActionPreference = 'Stop'
foreach ($p in $args) {
    if ($p -match '^https://') { Start-Process -FilePath $p; Write-Output ("OPENED: " + $p); continue }
    $f = (Resolve-Path -LiteralPath $p).Path; Start-Process -FilePath $f; Write-Output ("OPENED: " + $f)
}
