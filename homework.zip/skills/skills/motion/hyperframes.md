# HyperFrames — как работать

HyperFrames — бесплатный движок (лицензия Apache 2.0): берёт страницу HTML с анимацией GSAP и снимает её в MP4 кадр за кадром в безголовом браузере. Версия, на которой проверен этот навык, — 0.8.205. Нужны Node 22+ и ffmpeg.

## Установка (без глобальных флагов)

В папке проекта (не в системной):

```
npm install hyperframes gsap
```

Запуск — через `npx hyperframes <команда>` из этой папки. Если нужно, чтобы npx не пытался докачивать лишнее, добавь `--no-install`.

## Браузер

HyperFrames использует Chrome. Надёжнее — безголовая сборка chrome-headless-shell: она не открывает окон. Поставь её командой `npx hyperframes browsers install chrome-headless-shell@stable --path ./browsers` (если такой команды нет в твоей версии, смотри `npx hyperframes --help`) и укажи путь к ней переменной окружения `HYPERFRAMES_BROWSER_PATH`.

На Windows обычный Chrome движок запускает как `chrome.exe --version`, и это может открыть видимое окно. Поэтому команду `doctor` без заданного браузера не запускай.

Чтобы отключить статистику, проверку обновлений и самоустановку лишнего, перед командами задай переменные окружения:
`HYPERFRAMES_NO_TELEMETRY=1`, `HYPERFRAMES_NO_UPDATE_CHECK=1`, `HYPERFRAMES_NO_AUTO_INSTALL=1`, `HYPERFRAMES_NO_OPTIONAL_INSTALL=1`, `HYPERFRAMES_SKIP_SKILLS=1`.

## Команды

- `init <имя> --example blank --resolution portrait --non-interactive --skip-skills --skip-transcribe` — заготовка проекта.
- `lint <папка>` — проверка правил разметки.
- `validate <папка>` — ошибки консоли и контраст в безголовом браузере.
- `snapshot <папка> -o <куда> --at 0,1.5,... --no-end` — кадры PNG и контактные листы.
- `render <папка> -o файл.mp4` — рендер.

## Устройство ролика

- Корень: `data-composition-id="main"`, `data-duration`, `data-width`, `data-height`. Каждый временный элемент — `class="clip"`, `data-start`, `data-duration` (в секундах).
- Одна линия GSAP: `gsap.timeline({paused:true})` и `window.__timelines["main"] = tl`. Без `Date.now`, случайных чисел, таймеров и `repeat:-1`.
- У `.clip` не меняй `display` и `visibility` — анимируй вложенные элементы. Не двигай `top`, `left`, `width`; для движения — `x`, `y`, `scale`, `opacity`.
- GSAP — файл в проекте (`assets/gsap.min.js` из `node_modules/gsap/dist/`), не ссылка на CDN.
- Шрифты: встроенные — только латиница. Для русского: `@font-face { font-family: "Ru"; src: local("Segoe UI Black"); }` (на Mac — любой системный жирный шрифт с кириллицей, например `local("Helvetica Neue Bold")`).
- Сцена — это функция от времени `t`: один и тот же кадр при любом запуске. Так рендер повторяем.

## Что ломается

| Что | Причина | Лечение |
|---|---|---|
| Окно Chrome открывается при `doctor` или `render` | обычный Chrome запускается как `chrome.exe --version` | безголовый браузер через `HYPERFRAMES_BROWSER_PATH` |
| Кадры статичны, все слова видны сразу | не скопирован `assets/gsap.min.js` | `validate` пишет «404 loading assets/gsap.min.js»; всегда читай его вывод |
| Буквы двух сцен слиплись | текст прошлой сцены уходит позже входа следующей | закончить выход текста до входа нового |
| `lint`: gsap_non_transform_motion | анимировал `top` | заменить на `y` |
| `lint`: gsap_repeated_fromto_without_baseline | два `fromTo` на одном элементе | предупреждение; при проблемах — `immediateRender:false` на поздних |
| Команда оболочки оборвалась | длинный `cat <<EOF` с кавычками внутри | файлы создавай редактором или инструментом записи |
| `init` или `render` пишут EISDIR (link … owner.pid) | Windows не даёт жёсткую ссылку на папку | не мешает: заготовка и MP4 создаются, пропадает только запись статистики |

## Нагрузка на компьютер

Рендер тяжёлый. Запускай один процесс, а не несколько. Большие сцены с размытием в движении рендери по одной. Параллельный рендер кусками на слабом ноутбуке подвесит систему.
