#!/bin/bash
# Copies the skill folders from skills/ into the Claude Code skills folder. Replaces and deletes nothing.
# Run: bash install.sh
here="$(cd "$(dirname "$0")" && pwd)"
dst="$HOME/.claude/skills"
mkdir -p "$dst"
copied=0; kept=0
for d in "$here"/skills/*/; do
  name="$(basename "$d")"
  if [ -e "$dst/$name" ]; then echo "already there, left as is: $name"; kept=$((kept+1))
  else cp -R "$d" "$dst/$name" && echo "installed: $name" && copied=$((copied+1)); fi
done
echo "Done: installed $copied, skipped $kept. Folder: $dst"
