# Copies the skill folders from skills\ into the Claude Code skills folder. Replaces and deletes nothing.
# Run: powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1
$ErrorActionPreference = 'Stop'
$src = Join-Path $PSScriptRoot 'skills'
$dst = Join-Path $env:USERPROFILE '.claude\skills'
New-Item -ItemType Directory -Force -Path $dst | Out-Null
$copied = 0; $kept = 0
Get-ChildItem -Path $src -Directory | ForEach-Object {
    $target = Join-Path $dst $_.Name
    if (Test-Path $target) { Write-Output ("already there, left as is: " + $_.Name); $kept++ }
    else { Copy-Item -Path $_.FullName -Destination $target -Recurse; Write-Output ("installed: " + $_.Name); $copied++ }
}
Write-Output ("Done: installed $copied, skipped $kept. Folder: $dst")
